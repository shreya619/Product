package com.example.productservice.service;

import com.example.productservice.*;
import com.example.productservice.model.Product;
import com.example.productservice.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;

import com.example.productservice.model.Product;
import com.example.productservice.repository.*;

@Service
public class ProductService {
    public ProductService(ProductRepository productRepository) {
		super();
		this.productRepository = productRepository;
	}

	private final ProductRepository productRepository;

	public List<Product> getAllProducts() {
	    List<Product> products = productRepository.findAll();
	    
	    if (products.isEmpty()) {
	        throw new ProductNotFoundException("No products found");
	    }

	    return products;
	}

    public Product getProductById(int id) {
        return productRepository.findByproductId(id)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with ID: " + id));
    }


    public Product getProductByName(String name) {
        return productRepository.findByproductName(name)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with name: "+name));
    }

    public Product addProduct(Product product) {
        
        return productRepository.save(product);
    }

    public Product updateProduct(int id, Product product) {
        Product existingProduct = productRepository.findByproductId(id)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with ID: " + id));

        existingProduct.setProductName(product.getProductName());
        existingProduct.setProductPrice(product.getProductPrice());
        
        return productRepository.save(existingProduct);
    }

    @Transactional
    
    public void deleteProduct(int id) {
        Product product = productRepository.findByproductId(id)
            .orElseThrow(() -> new ProductNotFoundException("Product not found with id: "+id));
        productRepository.delete(product);
    }
}

	


