package com.example.productservice.repository;


import com.example.productservice.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;



import org.springframework.stereotype.Repository;

import com.example.productservice.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> 
{
    Optional<Product> findByproductName(String name);
    Optional<Product> findByproductId(int id);
    Optional<Product> deleteByproductId(int id);
	boolean existsById(int id);
}
