package com.example.productservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.productservice.model.*;

public interface UserRepository extends JpaRepository<User, Long>
{

	User findByUsername(String username);

}
